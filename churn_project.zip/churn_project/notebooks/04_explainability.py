# ============================================================
# PROJECT 1 — CUSTOMER CHURN PREDICTOR
# FILE: 04_explainability.py  |  DAY 4 MORNING
# ============================================================

# CELL 1 — Imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import pickle, warnings
warnings.filterwarnings('ignore')
import shap

# CELL 2 — Load model and test data
model   = pickle.load(open('xgb_model.pkl','rb'))
X_test  = pd.read_csv('X_test.csv')
y_test  = pd.read_csv('y_test.csv').squeeze()
print("Model and data loaded")
print("Test samples:", X_test.shape[0])

# CELL 3 — Create SHAP explainer
explainer   = shap.TreeExplainer(model)
shap_values = explainer.shap_values(X_test)
print("SHAP values computed. Shape:", shap_values.shape)

# CELL 4 — Global feature importance (bar plot)
plt.figure(figsize=(10,8))
shap.summary_plot(shap_values, X_test,
                  plot_type="bar",
                  max_display=20,
                  show=False)
plt.title("Top 20 Features by Mean SHAP Value",
          fontsize=14, fontweight='bold', pad=20)
plt.tight_layout()
plt.savefig('shap_global_importance.png', dpi=150, bbox_inches='tight')
plt.show()
print("""
INSIGHT: Contract_Month-to-month and tenure are the top drivers.
This confirms our EDA findings. The model learned what the data showed.
""")

# CELL 5 — Beeswarm plot (direction of impact)
plt.figure(figsize=(10,8))
shap.summary_plot(shap_values, X_test,
                  max_display=20,
                  show=False)
plt.title("SHAP Beeswarm — Feature Impact Direction",
          fontsize=14, fontweight='bold', pad=20)
plt.tight_layout()
plt.savefig('shap_beeswarm.png', dpi=150, bbox_inches='tight')
plt.show()
print("""
INSIGHT: Red = high feature value, Blue = low feature value.
High MonthlyCharges (red) pushes toward churn (positive SHAP).
Long tenure (red) pushes against churn (negative SHAP).
""")

# CELL 6 — SHAP for a single high-risk customer
# Find a customer the model thinks is high churn risk
probs = model.predict_proba(X_test)[:,1]
high_risk_idx = probs.argmax()
print(f"\nHighest risk customer index: {high_risk_idx}")
print(f"Predicted churn probability: {probs[high_risk_idx]:.2%}")
print(f"Actual churn: {y_test.iloc[high_risk_idx]}")

plt.figure(figsize=(12,4))
shap.waterfall_plot(
    shap.Explanation(
        values=shap_values[high_risk_idx],
        base_values=explainer.expected_value,
        data=X_test.iloc[high_risk_idx],
        feature_names=X_test.columns.tolist()
    ),
    max_display=15,
    show=False
)
plt.title(f"Why Customer #{high_risk_idx} Is Predicted to Churn",
          fontsize=13, fontweight='bold')
plt.tight_layout()
plt.savefig('shap_single_customer.png', dpi=150, bbox_inches='tight')
plt.show()

# CELL 7 — SHAP for a low-risk customer
low_risk_idx = probs.argmin()
print(f"\nLowest risk customer index: {low_risk_idx}")
print(f"Predicted churn probability: {probs[low_risk_idx]:.2%}")

plt.figure(figsize=(12,4))
shap.waterfall_plot(
    shap.Explanation(
        values=shap_values[low_risk_idx],
        base_values=explainer.expected_value,
        data=X_test.iloc[low_risk_idx],
        feature_names=X_test.columns.tolist()
    ),
    max_display=15,
    show=False
)
plt.title(f"Why Customer #{low_risk_idx} Is Predicted to Stay",
          fontsize=13, fontweight='bold')
plt.tight_layout()
plt.savefig('shap_low_risk_customer.png', dpi=150, bbox_inches='tight')
plt.show()

# CELL 8 — SHAP dependence plot (tenure vs churn)
plt.figure(figsize=(8,5))
shap.dependence_plot('tenure', shap_values, X_test,
                     interaction_index='MonthlyCharges',
                     show=False)
plt.title("SHAP Dependence: Tenure Effect on Churn",
          fontsize=13, fontweight='bold')
plt.tight_layout()
plt.savefig('shap_dependence_tenure.png', dpi=150, bbox_inches='tight')
plt.show()
print("""
INSIGHT: Short tenure + high monthly charges = maximum churn impact.
This is the exact customer segment to target for retention campaigns.
""")

# CELL 9 — Business summary table
top_features = pd.DataFrame({
    'Feature': X_test.columns,
    'Mean_SHAP': np.abs(shap_values).mean(axis=0)
}).sort_values('Mean_SHAP', ascending=False).head(10)

print("\nTop 10 churn drivers:")
print(top_features.to_string(index=False))

print("\n" + "="*50)
print("DAY 4 MORNING COMPLETE — SHAP explainability done")
print("5 SHAP charts saved. Now build Streamlit app.")
print("="*50)
