# ============================================================
# PROJECT 1 — CUSTOMER CHURN PREDICTOR
# FILE: 03_modeling.py  |  DAY 3
# ============================================================

# CELL 1 — Imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import pickle, json, warnings
warnings.filterwarnings('ignore')

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (classification_report, roc_auc_score,
                              confusion_matrix, ConfusionMatrixDisplay,
                              roc_curve, precision_recall_curve)
from xgboost import XGBClassifier
from sklearn.model_selection import RandomizedSearchCV
import mlflow
import mlflow.sklearn

# CELL 2 — Load preprocessed data
X_train = pd.read_csv('X_train.csv')
X_val   = pd.read_csv('X_val.csv')
X_test  = pd.read_csv('X_test.csv')
y_train = pd.read_csv('y_train.csv').squeeze()
y_val   = pd.read_csv('y_val.csv').squeeze()
y_test  = pd.read_csv('y_test.csv').squeeze()
print("Data loaded. Train size:", X_train.shape)

# CELL 3 — Define 3 models to compare
models = {
    'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
    'Random Forest':       RandomForestClassifier(n_estimators=150, random_state=42, n_jobs=-1),
    'XGBoost':             XGBClassifier(n_estimators=200, learning_rate=0.05,
                                          max_depth=5, subsample=0.8,
                                          colsample_bytree=0.8,
                                          use_label_encoder=False,
                                          eval_metric='logloss',
                                          random_state=42)
}

# CELL 4 — Train all models and track with MLflow
mlflow.set_experiment("churn-prediction")
results = {}

for name, model in models.items():
    with mlflow.start_run(run_name=name):
        # Train
        model.fit(X_train, y_train)

        # Predict on validation set
        y_pred = model.predict(X_val)
        y_prob = model.predict_proba(X_val)[:,1]

        # Metrics
        auc  = roc_auc_score(y_val, y_prob)
        report = classification_report(y_val, y_pred, output_dict=True)
        precision = report['1']['precision']
        recall    = report['1']['recall']
        f1        = report['1']['f1-score']

        results[name] = {
            'model': model,
            'auc': auc,
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'y_prob': y_prob
        }

        # Log to MLflow
        mlflow.log_param("model_type", name)
        mlflow.log_metric("roc_auc", auc)
        mlflow.log_metric("precision", precision)
        mlflow.log_metric("recall", recall)
        mlflow.log_metric("f1_score", f1)
        mlflow.sklearn.log_model(model, name.replace(" ","_"))

        print(f"\n{'='*40}")
        print(f"Model: {name}")
        print(f"AUC-ROC:   {auc:.4f}")
        print(f"Precision: {precision:.4f}")
        print(f"Recall:    {recall:.4f}")
        print(f"F1 Score:  {f1:.4f}")
        print(classification_report(y_val, y_pred))

# CELL 5 — Compare models visually
metrics_df = pd.DataFrame({
    name: {k:v for k,v in vals.items() if k not in ['model','y_prob']}
    for name, vals in results.items()
}).T

fig, ax = plt.subplots(figsize=(10,5))
x = np.arange(len(metrics_df.columns))
width = 0.25
colors = ['#378ADD','#1D9E75','#D85A30']
for i, (idx, row) in enumerate(metrics_df.iterrows()):
    ax.bar(x + i*width, row.values, width, label=idx, color=colors[i], alpha=0.85)
ax.set_xticks(x + width)
ax.set_xticklabels(metrics_df.columns)
ax.set_ylim(0.5, 1.0)
ax.set_title('Model Comparison — Validation Set', fontsize=14, fontweight='bold')
ax.set_ylabel('Score')
ax.legend()
plt.tight_layout(); plt.show()

# CELL 6 — ROC curves for all models
fig, ax = plt.subplots(figsize=(8,6))
for name, vals in results.items():
    fpr, tpr, _ = roc_curve(y_val, vals['y_prob'])
    ax.plot(fpr, tpr, label=f"{name} (AUC={vals['auc']:.3f})", linewidth=2)
ax.plot([0,1],[0,1],'k--', alpha=0.4, label='Random')
ax.set_title('ROC Curves — All Models', fontsize=14, fontweight='bold')
ax.set_xlabel('False Positive Rate')
ax.set_ylabel('True Positive Rate')
ax.legend(); plt.tight_layout(); plt.show()

# CELL 7 — Confusion matrix for best model (XGBoost)
best_name = max(results, key=lambda x: results[x]['auc'])
best_model = results[best_name]['model']
print(f"\nBest model: {best_name} (AUC={results[best_name]['auc']:.4f})")

y_pred_best = best_model.predict(X_val)
fig, ax = plt.subplots(figsize=(6,5))
ConfusionMatrixDisplay.from_predictions(y_val, y_pred_best,
    display_labels=['Stayed','Churned'],
    cmap='Blues', ax=ax)
ax.set_title(f'Confusion Matrix — {best_name}', fontsize=14, fontweight='bold')
plt.tight_layout(); plt.show()

# CELL 8 — Hyperparameter tuning on XGBoost
print("\nRunning RandomizedSearchCV — this takes ~3 minutes...")
param_grid = {
    'n_estimators':     [100, 200, 300, 400],
    'max_depth':        [3, 4, 5, 6, 7],
    'learning_rate':    [0.01, 0.05, 0.1, 0.15],
    'subsample':        [0.7, 0.8, 0.9, 1.0],
    'colsample_bytree': [0.7, 0.8, 0.9, 1.0],
    'min_child_weight': [1, 3, 5],
    'gamma':            [0, 0.1, 0.2]
}

xgb_base = XGBClassifier(use_label_encoder=False,
                           eval_metric='logloss', random_state=42)
search = RandomizedSearchCV(
    xgb_base, param_grid,
    n_iter=30, scoring='roc_auc',
    cv=5, random_state=42, n_jobs=-1, verbose=1
)
search.fit(X_train, y_train)

print(f"\nBest params: {search.best_params_}")
print(f"Best CV AUC: {search.best_score_:.4f}")

tuned_model = search.best_estimator_

# CELL 9 — Evaluate tuned model on TEST set (final evaluation)
y_test_prob = tuned_model.predict_proba(X_test)[:,1]
y_test_pred = tuned_model.predict(X_test)
test_auc    = roc_auc_score(y_test, y_test_prob)

print(f"\n{'='*50}")
print(f"FINAL TEST SET RESULTS — Tuned XGBoost")
print(f"Test AUC-ROC: {test_auc:.4f}")
print(classification_report(y_test, y_test_pred,
      target_names=['Stayed','Churned']))
print("="*50)

# CELL 10 — Save final model
pickle.dump(tuned_model, open('xgb_model.pkl','wb'))
print("\nModel saved as xgb_model.pkl")

with mlflow.start_run(run_name="XGBoost_Tuned_FINAL"):
    mlflow.log_params(search.best_params_)
    mlflow.log_metric("test_roc_auc", test_auc)
    mlflow.sklearn.log_model(tuned_model, "xgb_tuned_final")

print("\n" + "="*50)
print("DAY 3 COMPLETE — 3 models trained, compared, tuned")
print(f"Final test AUC: {test_auc:.4f}")
print("Model saved. Run 04_explainability.py next")
print("="*50)
