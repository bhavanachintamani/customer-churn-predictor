# ============================================================
# PROJECT 1 — CUSTOMER CHURN PREDICTOR
# FILE: 02_preprocessing.py  |  DAY 2
# ============================================================

# CELL 1 — Imports
import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
import pickle
import warnings
warnings.filterwarnings('ignore')

# CELL 2 — Load data
df = pd.read_csv('telco_churn.csv')
df['TotalCharges'] = pd.to_numeric(df['TotalCharges'], errors='coerce')
df['TotalCharges'].fillna(df['TotalCharges'].median(), inplace=True)
print("Loaded:", df.shape)

# CELL 3 — Drop customer ID (not a feature)
df.drop('customerID', axis=1, inplace=True)

# CELL 4 — Encode binary Yes/No columns
binary_cols = ['gender','Partner','Dependents','PhoneService',
               'PaperlessBilling']
le = LabelEncoder()
for col in binary_cols:
    df[col] = le.fit_transform(df[col])
    print(f"Encoded {col}: {df[col].unique()}")

# CELL 5 — Encode target column
df['Churn'] = df['Churn'].map({'Yes': 1, 'No': 0})
print("\nChurn encoded. Value counts:\n", df['Churn'].value_counts())

# CELL 6 — One-hot encode multi-category columns
multi_cols = ['MultipleLines','InternetService','OnlineSecurity',
              'OnlineBackup','DeviceProtection','TechSupport',
              'StreamingTV','StreamingMovies','Contract','PaymentMethod']
df = pd.get_dummies(df, columns=multi_cols, drop_first=False)
print("\nAfter one-hot encoding shape:", df.shape)
print("Columns:", df.columns.tolist())

# CELL 7 — Feature engineering (3 new features)
# Feature 1: charge per month relative to tenure
df['ChargePerTenure'] = df['MonthlyCharges'] / (df['tenure'] + 1)

# Feature 2: total number of services subscribed
service_cols = [c for c in df.columns if any(x in c for x in
    ['MultipleLines','OnlineSecurity','OnlineBackup',
     'DeviceProtection','TechSupport','StreamingTV','StreamingMovies'])
    and '_Yes' in c]
df['TotalServices'] = df[service_cols].sum(axis=1)

# Feature 3: is new customer (tenure under 12 months)
df['IsNewCustomer'] = (df['tenure'] < 12).astype(int)

print("\nNew features added:")
print("ChargePerTenure sample:", df['ChargePerTenure'].head(3).values)
print("TotalServices sample:", df['TotalServices'].head(3).values)
print("IsNewCustomer sample:", df['IsNewCustomer'].head(3).values)

# CELL 8 — Split features and target
X = df.drop('Churn', axis=1)
y = df['Churn']
print(f"\nFeatures: {X.shape[1]} | Samples: {X.shape[0]}")

# CELL 9 — Train / validation / test split (60/20/20)
X_temp, X_test, y_temp, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)
X_train, X_val, y_train, y_val = train_test_split(
    X_temp, y_temp, test_size=0.25, random_state=42, stratify=y_temp)
print(f"\nTrain: {X_train.shape[0]} | Val: {X_val.shape[0]} | Test: {X_test.shape[0]}")
print(f"Train churn rate: {y_train.mean():.3f}")
print(f"Test churn rate:  {y_test.mean():.3f}")

# CELL 10 — Scale numerical features
num_cols = ['tenure','MonthlyCharges','TotalCharges','ChargePerTenure','TotalServices']
scaler = StandardScaler()
X_train[num_cols] = scaler.fit_transform(X_train[num_cols])
X_val[num_cols]   = scaler.transform(X_val[num_cols])
X_test[num_cols]  = scaler.transform(X_test[num_cols])
print("\nScaling done. Train MonthlyCharges mean:", X_train['MonthlyCharges'].mean().round(4))

# CELL 11 — Save processed data and column list
X_train.to_csv('X_train.csv', index=False)
X_val.to_csv('X_val.csv', index=False)
X_test.to_csv('X_test.csv', index=False)
y_train.to_csv('y_train.csv', index=False)
y_val.to_csv('y_val.csv', index=False)
y_test.to_csv('y_test.csv', index=False)
pickle.dump(scaler, open('scaler.pkl','wb'))

# Save column names for Streamlit app
import json
with open('feature_columns.json','w') as f:
    json.dump(X_train.columns.tolist(), f)

print("\n" + "="*50)
print("DAY 2 COMPLETE — Data cleaned, engineered, split, saved")
print(f"Total features ready for modeling: {X_train.shape[1]}")
print("Files saved: X_train.csv, X_test.csv, scaler.pkl, feature_columns.json")
print("Run 03_modeling.py next")
print("="*50)
