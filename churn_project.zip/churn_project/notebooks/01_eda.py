# ============================================================
# PROJECT 1 — CUSTOMER CHURN PREDICTOR
# FILE: 01_eda.py  |  DAY 1
# Run each cell block in Google Colab
# ============================================================

# CELL 1 — Install (run once)
# !pip install pandas numpy matplotlib seaborn scikit-learn xgboost shap streamlit mlflow plotly

# CELL 2 — Imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')
plt.rcParams['figure.figsize'] = (10, 5)
plt.rcParams['axes.spines.top']   = False
plt.rcParams['axes.spines.right'] = False

# CELL 3 — Load data
# Upload telco_churn.csv to Colab first (Files panel on left sidebar)
df = pd.read_csv('telco_churn.csv')
print("Shape:", df.shape)
print("\nColumns:", df.columns.tolist())
print("\nData types:\n", df.dtypes)
print("\nNull values:\n", df.isnull().sum())
print("\nFirst 5 rows:\n", df.head())

# CELL 4 — Fix TotalCharges bug (stored as string, not number)
df['TotalCharges'] = pd.to_numeric(df['TotalCharges'], errors='coerce')
print("Missing TotalCharges after fix:", df['TotalCharges'].isnull().sum())
df['TotalCharges'].fillna(df['TotalCharges'].median(), inplace=True)
print("Fixed. No more nulls:", df['TotalCharges'].isnull().sum())

# CELL 5 — Chart 1: Churn distribution
churn_counts = df['Churn'].value_counts()
churn_pct    = df['Churn'].value_counts(normalize=True) * 100
fig, ax = plt.subplots()
bars = ax.bar(churn_counts.index, churn_counts.values,
              color=['#378ADD','#D85A30'], width=0.4)
for bar, pct in zip(bars, churn_pct.values):
    ax.text(bar.get_x() + bar.get_width()/2,
            bar.get_height() + 50,
            f'{pct:.1f}%', ha='center', fontsize=12, fontweight='bold')
ax.set_title('Churn Distribution', fontsize=14, fontweight='bold')
ax.set_ylabel('Number of Customers')
plt.tight_layout(); plt.show()
print("INSIGHT: 26.5% churned — class imbalance. Use AUC-ROC not accuracy.")

# CELL 6 — Chart 2: Churn by Contract type
fig, ax = plt.subplots()
df.groupby(['Contract','Churn']).size().unstack().plot(
    kind='bar', ax=ax, color=['#378ADD','#D85A30'], width=0.6)
ax.set_title('Churn by Contract Type', fontsize=14, fontweight='bold')
ax.set_xlabel('Contract Type'); ax.set_ylabel('Customers')
ax.legend(['No Churn','Churned']); ax.set_xticklabels(ax.get_xticklabels(), rotation=0)
plt.tight_layout(); plt.show()
print("INSIGHT: Month-to-month churns at ~42% vs ~3% for 2-year. Strongest predictor.")

# CELL 7 — Chart 3: Tenure distribution
fig, ax = plt.subplots()
df[df['Churn']=='Yes']['tenure'].hist(bins=30, alpha=0.7, color='#D85A30', label='Churned', ax=ax)
df[df['Churn']=='No']['tenure'].hist(bins=30, alpha=0.7, color='#378ADD', label='Stayed', ax=ax)
ax.set_title('Tenure Distribution by Churn', fontsize=14, fontweight='bold')
ax.set_xlabel('Tenure (months)'); ax.set_ylabel('Count'); ax.legend()
plt.tight_layout(); plt.show()
print("INSIGHT: Churners concentrated in first 12 months. IsNewCustomer feature will help.")

# CELL 8 — Chart 4: Monthly charges boxplot
fig, ax = plt.subplots()
churned    = df[df['Churn']=='Yes']['MonthlyCharges']
not_churned = df[df['Churn']=='No']['MonthlyCharges']
ax.boxplot([not_churned, churned], labels=['Stayed','Churned'],
           patch_artist=True,
           boxprops=dict(facecolor='#B5D4F4', color='#185FA5'),
           medianprops=dict(color='#D85A30', linewidth=2))
ax.set_title('Monthly Charges by Churn', fontsize=14, fontweight='bold')
ax.set_ylabel('Monthly Charges ($)')
plt.tight_layout(); plt.show()
print("INSIGHT: Churned median ~$79 vs $65 for stayed. High charges = higher risk.")

# CELL 9 — Chart 5: Correlation heatmap
fig, ax = plt.subplots(figsize=(8,6))
numeric_df = df.select_dtypes(include=np.number)
mask = np.triu(np.ones_like(numeric_df.corr(), dtype=bool))
sns.heatmap(numeric_df.corr(), mask=mask, annot=True, fmt='.2f',
            cmap='Blues', ax=ax, linewidths=0.5)
ax.set_title('Feature Correlation Heatmap', fontsize=14, fontweight='bold')
plt.tight_layout(); plt.show()
print("INSIGHT: tenure & TotalCharges highly correlated (0.83) — expected.")

# CELL 10 — Chart 6: Internet service
fig, ax = plt.subplots()
df.groupby(['InternetService','Churn']).size().unstack().plot(
    kind='bar', ax=ax, color=['#378ADD','#D85A30'], width=0.6)
ax.set_title('Churn by Internet Service', fontsize=14, fontweight='bold')
ax.set_xticklabels(ax.get_xticklabels(), rotation=0)
ax.legend(['No Churn','Churned']); ax.set_ylabel('Count')
plt.tight_layout(); plt.show()
print("INSIGHT: Fiber optic churns at ~41% vs DSL ~19%. Quality or pricing issue.")

# CELL 11 — Chart 7: Payment method
fig, ax = plt.subplots(figsize=(10,5))
df.groupby(['PaymentMethod','Churn']).size().unstack().plot(
    kind='bar', ax=ax, color=['#378ADD','#D85A30'], width=0.6)
ax.set_title('Churn by Payment Method', fontsize=14, fontweight='bold')
ax.set_xticklabels(ax.get_xticklabels(), rotation=15)
ax.legend(['No Churn','Churned']); ax.set_ylabel('Count')
plt.tight_layout(); plt.show()
print("INSIGHT: Electronic check = 45% churn. Auto-pay = low churn. Manual = friction.")

# CELL 12 — Chart 8: Tenure vs charges scatter
fig, ax = plt.subplots()
colors = df['Churn'].map({'Yes':'#D85A30','No':'#378ADD'})
ax.scatter(df['tenure'], df['MonthlyCharges'], c=colors, alpha=0.3, s=15)
ax.set_title('Tenure vs Monthly Charges (by Churn)', fontsize=14, fontweight='bold')
ax.set_xlabel('Tenure (months)'); ax.set_ylabel('Monthly Charges ($)')
from matplotlib.patches import Patch
ax.legend(handles=[Patch(facecolor='#D85A30',label='Churned'),
                   Patch(facecolor='#378ADD',label='Stayed')])
plt.tight_layout(); plt.show()
print("INSIGHT: Top-left = low tenure + high charges = maximum churn risk zone.")

print("\n" + "="*50)
print("DAY 1 COMPLETE — 8 charts, 8 business insights")
print("Save notebook. Push to GitHub. Run 02_preprocessing.py tomorrow.")
print("="*50)
