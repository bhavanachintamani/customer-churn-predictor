# Customer Churn Predictor

## Problem Statement
Telecom companies lose ~26% of customers annually to churn. Identifying at-risk customers early enables targeted retention campaigns — saving thousands of dollars per customer prevented from leaving.

## Solution
End-to-end ML pipeline: EDA → Feature Engineering → XGBoost Model (AUC ~0.85) → SHAP Explainability → Live Streamlit Dashboard

## Live Demo
[🚀 Try the live app here](https://your-app-name.streamlit.app)

## Tech Stack
| Layer | Tools |
|---|---|
| Language | Python 3.10 |
| Data | Pandas, NumPy |
| ML | Scikit-learn, XGBoost |
| Explainability | SHAP |
| Experiment Tracking | MLflow |
| Dashboard | Streamlit |
| Dataset | IBM Telco Customer Churn (7,043 rows) |

## Key Results
- **ROC-AUC: ~0.85** on held-out test set
- **Top churn drivers:** Contract type, tenure, monthly charges (confirmed by SHAP)
- **3 engineered features** improved model performance over baseline

## Project Structure
```
customer-churn-predictor/
├── data/                  ← Dataset (not committed, download from Kaggle)
├── notebooks/
│   ├── 01_eda.py          ← 8 charts + business insights
│   ├── 02_preprocessing.py← Cleaning, encoding, feature engineering
│   ├── 03_modeling.py     ← 3 models compared, XGBoost tuned
│   └── 04_explainability.py← SHAP global + individual explanations
├── app/
│   └── streamlit_app.py   ← Full interactive dashboard
├── models/
│   └── xgb_model.pkl      ← Saved tuned model
├── requirements.txt
└── README.md
```

## How to Run Locally
```bash
git clone https://github.com/yourusername/customer-churn-predictor
cd customer-churn-predictor
pip install -r requirements.txt

# Run notebooks in order: 01 → 02 → 03 → 04
# Then launch dashboard:
streamlit run app/streamlit_app.py
```

## Architecture
```
Raw CSV → EDA (8 charts) → Preprocessing → Feature Engineering (3 new)
→ Model Comparison (LR / RF / XGBoost) → Hyperparameter Tuning
→ SHAP Explainability → Streamlit Dashboard → Streamlit Cloud Deploy
```

## Business Impact
- Identifies top 26% churn-risk customers before they leave
- SHAP explanations allow business teams to understand predictions without ML knowledge
- Actionable retention recommendations built into dashboard

---
Built by Bhavana Aswin | B.Tech CS (AI) | Data Scientist
